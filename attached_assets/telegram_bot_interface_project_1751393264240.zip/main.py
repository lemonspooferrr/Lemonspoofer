from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
import os
import json
from config import NOWPAYMENTS_API_KEY
from utils import generate_payment_link, check_payment_status

DATA_FILE = "database.json"

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump({}, f)

def load_data():
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)
    data = load_data()

    if user_id not in data:
        data[user_id] = {"paid": False}
        save_data(data)

    keyboard = [
        [InlineKeyboardButton("💳 Acheter licence à vie (200€)", callback_data="buy_license")],
        [InlineKeyboardButton("📞 Spoof Call", callback_data="spoof_call")],
        [InlineKeyboardButton("📩 Spoof SMS", callback_data="spoof_sms")]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Bienvenue sur le bot. Choisissez une option :", reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = str(query.from_user.id)
    data = load_data()
    user = data.get(user_id, {"paid": False})

    if query.data == "buy_license":
        link = generate_payment_link(user_id)
        await query.edit_message_text(f"💳 Pour accéder au spoof, payez 200€ ici :
{link}")

    elif query.data == "spoof_call":
        if user["paid"]:
            await query.edit_message_text("📞 Entrez le numéro à appeler et le fake caller ID.")
        else:
            await query.edit_message_text("❌ Vous devez acheter une licence à vie d'abord.")

    elif query.data == "spoof_sms":
        if user["paid"]:
            await query.edit_message_text("📩 Entrez le numéro à envoyer et le message spoofé.")
        else:
            await query.edit_message_text("❌ Vous devez acheter une licence à vie d'abord.")

async def check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)
    data = load_data()

    if user_id not in data:
        await update.message.reply_text("Veuillez d'abord utiliser /start.")
        return

    if data[user_id]["paid"]:
        await update.message.reply_text("✅ Vous avez déjà acheté la licence.")
        return

    if check_payment_status(user_id):
        data[user_id]["paid"] = True
        save_data(data)
        await update.message.reply_text("✅ Paiement confirmé. Vous avez maintenant accès aux outils !")
    else:
        await update.message.reply_text("❌ Paiement non encore reçu. Réessayez plus tard.")

app = ApplicationBuilder().token(os.environ["TOKEN"]).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button_handler))
app.add_handler(CommandHandler("check", check))

app.run_polling()