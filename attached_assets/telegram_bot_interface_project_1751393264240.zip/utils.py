import requests

def generate_payment_link(user_id):
    url = "https://api.nowpayments.io/v1/invoice"
    payload = {
        "price_amount": 200,
        "price_currency": "eur",
        "order_id": user_id,
        "pay_currency": "btc"
    }
    headers = {
        "x-api-key": "KATH9CM-SS9MKHE-P2EW137-R65M539",
        "Content-Type": "application/json"
    }
    response = requests.post(url, json=payload, headers=headers)
    return response.json()["invoice_url"]

def check_payment_status(user_id):
    url = f"https://api.nowpayments.io/v1/payment"
    headers = {"x-api-key": "KATH9CM-SS9MKHE-P2EW137-R65M539"}
    response = requests.get(url, headers=headers)
    for payment in response.json().get("data", []):
        if payment["order_id"] == user_id and payment["payment_status"] == "confirmed":
            return True
    return False